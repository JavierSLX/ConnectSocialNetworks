package com.javiersl.libreria;

/**
 * Created by JavierSL on 17/05/2017.
 */
public class Mensaje
{
    public static final String principal = "Bienvenido al curso de Android Avanzado";
    public static final String design = "Android Material Design";
    public static final String conceptos = "Conceptos Avanzados de Android";
    public static final String aplicaciones = "Desarrollo de Aplicaciones Avanzadas en Android";
}
